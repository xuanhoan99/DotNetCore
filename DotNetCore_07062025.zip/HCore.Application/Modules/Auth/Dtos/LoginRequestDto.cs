﻿namespace HCore.Application.Modules.Auth.Dtos
{
    public class LoginRequestDto
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

}
