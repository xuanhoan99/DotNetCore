﻿namespace HCore.Application.Modules.Roles.Dtos
{
    public class RoleOuputDto
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
    }
}
