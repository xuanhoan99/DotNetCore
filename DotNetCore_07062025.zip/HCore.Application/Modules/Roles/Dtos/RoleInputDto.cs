﻿namespace HCore.Application.Modules.Roles.Dtos
{
    public class RoleInputDto
    {
        public string? Id { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
    }
}
