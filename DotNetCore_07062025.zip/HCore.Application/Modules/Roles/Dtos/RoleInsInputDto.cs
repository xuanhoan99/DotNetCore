﻿namespace HCore.Application.Modules.Roles.Dtos
{
    public class RoleInsInputDto
    {
        public string Name { get; set; }
        public string Desc { get; set; }
    }
}
